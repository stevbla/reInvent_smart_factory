var fs = require('fs');
var request = require('request');
var http = require('http');
var express = require("express");
var RED = require("node-red");

var RED_IP = 'http://127.0.0.1';
var RED_PORT = 1880;

var GG_ML_RESOURCE = '/flows'; //local path of the affiliated Greengrass Machine Learning Resource, which is a compressed file in S3
var NEWFLOW_FILE = GG_ML_RESOURCE + '/myflow.json'; //name of the flow file in GG_ML_RESOURCE
var GG_LOCAL_RESOURCE = '/nodered';
var BACKUP_FOLDER = GG_LOCAL_RESOURCE + '/backup';
var USER_DIR = GG_LOCAL_RESOURCE + '/userdir';

// Create an Express app
var app = express();
// Add a simple route for static content served from 'public'
app.use("/",express.static("public"));

// Create a server
var server = http.createServer(app);

// Create the settings object
var settings = {
    httpAdminRoot: "/red",
    //disableEditor: true,        //Disable the UI in production
    httpNodeRoot: "/api",
    userDir: USER_DIR,
    functionGlobalContext: {
      require:require
    }    //enables global context

    //TODO: authentication
};


function backupExistingFlows(fileName) {
  var options = {
    //https://nodered.org/docs/api/admin/methods/get/flows/
    uri: RED_IP + ':' + RED_PORT + '/red/flows',
    method: 'GET'
  };

  request(options, function(error, response, body) {
    if (!error && response.statusCode == 200) {
      fs.writeFile(fileName, body, function(err) {
        if (error) {
          return console.log('Flow file writing error: ' + error);
        }
        console.log('backed up the existing flows');

        console.log('loading the new flows after backup');
        loadNewFlows();
      });

    } else {
      console.log('HTTP Error while reading existing flow:', error);
    }
  });

}

function loadNewFlows() {
  console.log('load the latest flows available');
  fs.readFile(NEWFLOW_FILE, 'utf8', function(error, data) {
    if (error) {
      return console.log('Flow file reading error: ' + error);
    }

    var options = {
      //https://nodered.org/docs/api/admin/methods/post/flows/
      uri: RED_IP + ':' + RED_PORT + '/red/flows',
      method: 'POST',
      json: JSON.parse(data)
    };

    console.log('file was read, requesting REST API');
    request(options, function(error, response, body) {
      if (!error && response.statusCode == 204) {
        console.log('loaded the new flows');
      } else {
        console.log('HTTP Error while loading new flow:', error);
      }
    });
  });
}



function init() {
  console.log('Node-RED initializing...');
  RED.init(server,settings);

  app.use(settings.httpAdminRoot,RED.httpAdmin);  // Serve the editor UI from /red
  app.use(settings.httpNodeRoot,RED.httpNode);  // Serve the http nodes UI from /api

  server.listen(RED_PORT);

  return RED.start().then(() => {
    console.log('Node-RED server started.');

    //WARNING: In order to use REST API, Node-RED must be running. Undeserved flow may run before loading!
    //This can be solved by copying the flow to userDir as a JSON file. Must be validated!

    var fileName = BACKUP_FOLDER + '/flow-' + Date.now() + '.json';
    console.log('backing up the existing flows to: ' + fileName);
    backupExistingFlows(fileName);

  })
};


init();


exports.handler = function handler(event, context, callback) {
  console.log('This handler does not update the flow on GG core. Don\'t forget to deploy!');
  callback(undefined, { result: 'This handler does not update the flow on GG core.' });
};
